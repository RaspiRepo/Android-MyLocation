package raspirepo.mygpslocation;


import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.Socket;
import java.net.InetAddress;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.SelectableChannel;
import java.nio.ByteBuffer;
import java.util.Hashtable;
import java.util.Set;
import java.util.Iterator;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.TimeoutException;

import static android.content.Context.LOCATION_SERVICE;


public class tcp_client implements Runnable
/*----------------------------------------------------------------------------
    tcp_client.java     : tcp client thread to send coordinate information
                          to server

    Written By          : RaspiRepo
    Date                : Feb 2017
------------------------------------------------------------------------------*/
{
    private gps_constant constant;

    private Thread    thrd                = null;
    private Selector  selector            = null;

    private SocketChannel client_channel  = null;
    private Socket        tcp_socket      = null;
    private InputStream   instream        = null;
    private OutputStream  outstream       = null;

    private boolean connection_dropped = false;

    private String lastknown_location = "";

    private String server_ip   = "127.0.0.1";
    private int    server_port = 9999;

    private Context myapp_context   = null;



    public tcp_client (Context mycontext)
    /*------------------------------------------------------------------------
        tcp_client    : Simple tcp client to connect to server and
                        update current gps coordinate

        Written By    : RaspiRepo
        Date          : Feb 2017
    ------------------------------------------------------------------------*/
    {
        Log.d("tcp_client", "tcp_client instance created");
        myapp_context = mycontext;
    }



    public void set_server_to_connect (String serv_ip,
                                       int    port)
    /*------------------------------------------------------------------------
        set_server_to_connect
                      : Set server IP/port to connect and send gps
                        coordinate update

        Written By    : RaspiRepo
        Date          : Feb 2017
    ------------------------------------------------------------------------*/
    {
        server_ip    = serv_ip;
        server_port  = port;
        connection_dropped = true;
    }


    public void start ()
    /*------------------------------------------------------------------------
        start         : create threading to connect with server

        Written By    : RaspiRepo
        Date          : Feb 2017
    ------------------------------------------------------------------------*/
    {
        try {
            if (thrd == null) {
                thrd = new Thread(this);
            }
            thrd.start();
        } catch (Exception e) {
            System.out.println("exception in start:: " + e.getMessage());
        }
    }


    public void stop ()
    /*------------------------------------------------------------------------
        stop          : kill connect and thread

        Written By    : RaspiRepo
        Date          : Feb 2017
    ------------------------------------------------------------------------*/
    {
        try {
            thrd = null;
        } catch (Exception e) {
            System.out.println("exception in start:: " + e.getMessage());
        }
    }


    private void connect ()
    /*------------------------------------------------------------------------
        connect       : Method to create tcp connection to server

        Written By    : RaspiRepo
        Date          : Feb 2017
    ------------------------------------------------------------------------*/
    {
        try {
            if (connection_dropped == true) {

                tcp_socket = new Socket(server_ip, server_port);

                Log.d("tcp_client", "Connection success to "
                        + tcp_socket.getInetAddress().getHostAddress()
                        + " port " + tcp_socket.getPort());

                tcp_socket.setSoTimeout(30000);
                client_channel = tcp_socket.getChannel();
                instream = tcp_socket.getInputStream();
                outstream = tcp_socket.getOutputStream();
                connection_dropped = false;
                if (lastknown_location.length() > 0) {
                    write_to_socket(lastknown_location);
                }
            }
        } catch (Exception e) {
            Log.d("Tcp Client", "connect:exception " + e.getMessage());
        }
    }


    private void disconnect ()
    /*------------------------------------------------------------------------
        disconnect    : Disconnect socket connection with server

        Written By    : RaspiRepo
        Date          : Feb 2017
    ------------------------------------------------------------------------*/
    {
        try {
            tcp_socket.close();
            client_channel = null;
            instream       = null;
            outstream      = null;
            tcp_socket = null;
            connection_dropped = true;

            Log.d("tcp_client", "Connection Closed");

        } catch (Exception e) {
            Log.d("tcp_client","disconnect:exception " + e.getMessage());

        }
    }


    public void write_to_socket (String gps_loca)
    /*------------------------------------------------------------------------
        write_to_socket
                      : send message string to server

        Written By    : RaspiRepo
        Date          : Feb 2017
    ------------------------------------------------------------------------*/
    {
        try {
            lastknown_location = gps_loca;
            byte[] data = gps_loca.getBytes("UTF-8");
            outstream.write(data, 0, data.length);
            outstream.flush();
        } catch (Exception e) {
            Log.d("tcp_client","write_to_socket:exception " + e.getMessage());
            disconnect();
        }
    }



    public void run ()
    /*------------------------------------------------------------------------
        run           : client socket listen function. Get client socket
                        and add to client socket list

        Written By    : RaspiRepo
        Date          : Feb 2017
    ------------------------------------------------------------------------*/
    {
        int num_bytes_recvd = 0;
        ByteBuffer mesg_header = ByteBuffer.allocate(constant.HEADER_LENGTH);
        byte[] data_packet = mesg_header.array();
        //connection_dropped = true;

        while (thrd != null) {
            try {
                //in case connection dropped in middle 
                //reconnect untill new connection established
                //its possible either local network error or 
                //server may be off-line 
                while (connection_dropped == true) {
                    connect();
                    thrd.sleep(5000);
                }
                num_bytes_recvd = instream.read(data_packet, 0, constant.HEADER_LENGTH);

                //first fixed header is valid length
                if (num_bytes_recvd > 0
                        && mesg_header.hasArray()) {

                    //Log.d("bytes recvd ", "length " + num_bytes_recvd);
                    //Log.d("tcp_client","response " + new String(data_packet, 0, num_bytes_recvd));

                    //reset bytebuffer
                    mesg_header.flip();

                    //connection reset error
                } else if (num_bytes_recvd == -1) {
                    disconnect();
                }

                thrd.sleep(100);
            } catch (SocketTimeoutException er) {
                write_to_socket(lastknown_location);
                //System.out.println("TimeoutException in run : ");
            } catch (Exception ei) {

                System.out.println("Error in run : " + ei.getMessage());
            }
        }
        disconnect();
        Log.d("Tcp Client", "Connection wtih server and thread Terminated by App");
    }

}
