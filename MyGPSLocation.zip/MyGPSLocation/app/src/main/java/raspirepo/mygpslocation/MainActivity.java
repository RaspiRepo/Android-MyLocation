package raspirepo.mygpslocation;

import android.content.Intent;
import android.content.IntentFilter;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.net.wifi.WifiManager; // WifiManager
import android.widget.Switch;
import android.content.Context;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends AppCompatActivity implements LocationListener {
    public static final String latitude_val = "37° 23' 8.5\" N ";
    public static final String Longtitude_val = "121° 5' 2.3\" W";
    private gps_constant constant;

    private EditText latit_txt;
    private EditText longt_txt;
    private EditText port_txt;
    private EditText serv_ipddr_txt;

    private TextView curr_ipaddr;
    private WifiManager wm;
    private Switch gps_switch;
    private Context myapp_context;

    private String curr_lat_str = "";
    private String curr_log_str = "";

    private int    srv_port  = 9999;
    private String server_ip = "172.20.10.6"; //Default hotspot from iphone


    LocationManager locationManager = null;
    Location location = null;

    private static tcp_client gps_update_client = null;

    private static final String TAG = "MyActivity";
    private debug_log debug = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        myapp_context = MainActivity.this;


        gps_switch = (Switch) findViewById(R.id.gps_service_switch);
        latit_txt = (EditText) findViewById(R.id.Latitude_txt);
        longt_txt = (EditText) findViewById(R.id.longitude_txt);
        curr_ipaddr = (TextView) findViewById(R.id.ip_address);
        port_txt = (EditText) findViewById(R.id.listen_port);
        serv_ipddr_txt = (EditText) findViewById(R.id.server_ip);
        //server_ip = "192.168.0.102";
        serv_ipddr_txt.setText(server_ip);
        port_txt.setText(srv_port+"");

        debug = new debug_log(myapp_context);
        debug.open_debug_log();

        debug.write("Application start");

        wm = (WifiManager) getApplicationContext().getSystemService(getApplicationContext().WIFI_SERVICE);

        // Probably initialize members with default values for a new instance
        if (gps_update_client == null) {
            gps_update_client = new tcp_client(myapp_context);
            gps_update_client.set_server_to_connect(server_ip, srv_port);
            setup_location();
        }
        gps_update_client.start();
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy() connection and thread killed");

        gps_update_client.stop();
        gps_update_client = null;
        super.onDestroy();
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {

        // Save the user's current game state
        //savedInstanceState.putBinder("tcp_insta", gps_update_client);

        // Always call the superclass so it can save the view hierarchy state
        super.onSaveInstanceState(savedInstanceState);
    }

    /**
     * called when My location button clicked
     ****/
    public void onclick_mylocation(View view) {

        //Fill default value.

        WifiInfo wifiinfo = wm.getConnectionInfo();
        int ipnum = wifiinfo.getIpAddress();

        String ip_str = String.format("%d.%d.%d.%d", (ipnum & 0xff), (ipnum >> 8 & 0xff),
                (ipnum >> 16 & 0xff), (ipnum >> 24 & 0xff));
        /*
        if (gps_switch.isChecked() == true) {
            System.out.println("Enable GPS service on port " + port_txt.getText());
        } else {
            System.out.println("Disable GPS service on port " + port_txt.getText());
        }*/
        boolean chnage_ips = false;
        try {
            String curr_serv_ip = serv_ipddr_txt.getText().toString();
            String curr_serv_port = port_txt.getText().toString();
            int new_port = Integer.parseInt(curr_serv_port);


            if ((new_port > 0 && curr_serv_ip.length() > 0) && (new_port != srv_port || !curr_serv_ip.equalsIgnoreCase(server_ip))) {
                server_ip = curr_serv_ip;
                srv_port = new_port;
                chnage_ips = true;

            }
        } catch (Exception e) {
        }
        //System.out.println("chnage_ips " + chnage_ips);

        if (chnage_ips == true) {
            gps_update_client.stop();
            Log.d("Addresschanged", "New IP address " + server_ip + " port " + srv_port);
            gps_update_client.set_server_to_connect(server_ip, srv_port);
            gps_update_client.start();
        }
        curr_ipaddr.setText(ip_str);
        try {
            if (location != null){
                get_update_location(location);
            }
        } catch (Exception er) {
            System.out.println("Exception " + er.getMessage());
        }
    }



    private String format_gps_coordinate (double latitude,
                                          double longtiude)
    /*------------------------------------------------------------------------
        format_gps_coordinate
                      : Format gps location into coordinate string

        Written By    : K.Mariya (mariya.k@gmail.com)
        Date          : Feb 2017
    ------------------------------------------------------------------------*/
    {
        int degree_lat = (int)latitude;
        double md_lat = Math.abs(latitude - degree_lat) * 60;
        int m_lat = (int)md_lat;
        double sd_lat = ((md_lat - m_lat) * 60);

        int degree_longt = (int)longtiude;
        double md_longt = Math.abs(longtiude - degree_longt) * 60;
        int m_longt = (int)md_longt;
        double sd_longt = ((md_longt - m_longt) * 60);

        char lat_hemispr = 'N';
        if (degree_lat < 0) {
            lat_hemispr = 'S';
        }
        char logt_hemispr = 'E';
        if (degree_longt < 0) {
            logt_hemispr = 'W';
        }

        String gps_coor_str = "37° 23' 8.5\" N ";
        gps_coor_str = String.format("%d° %d` %2.1f\" %c", Math.abs(degree_lat),m_lat, sd_lat, lat_hemispr)
                + " " + String.format("%d° %d` %2.1f\" %c",  Math.abs(degree_longt),m_longt, sd_longt, logt_hemispr);

        //Log.d("Current Location ", gps_coor_str);

        return gps_coor_str;
    }



    private void setup_location ()
    /*------------------------------------------------------------------------
        setup_location
                      : Set up class instance required to register
                       location update.

        Written By    : K.Mariya (mariya.k@gmail.com)
        Date          : Feb 2017
    ------------------------------------------------------------------------*/
    {
        boolean isGPSEnabled     = false;
        boolean isNetworkEnabled = false;
        try {
            if (locationManager == null) {
                locationManager = (LocationManager) myapp_context.getSystemService(LOCATION_SERVICE);
            }

            if (locationManager != null) {
                isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

                // getting network status
                isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            }
            if (!isGPSEnabled && !isNetworkEnabled) {

            } else if (isNetworkEnabled) {
                // if GPS Enabled get lat/long using Network Services
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,
                        constant.MINI_TIME_BW_UPDATES_SECS,
                        constant.MIN_DISTANCE_MTRS_CHANGE_FOR_UPDATES, this);

                //Log.d("Location", "Network Enabled");
                if (locationManager != null) {
                    location = locationManager
                            .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }
            } else if (isGPSEnabled) {
                //Log.d("Location GPS", "GPS Enabled");
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                        constant.MINI_TIME_BW_UPDATES_SECS,
                        constant.MIN_DISTANCE_MTRS_CHANGE_FOR_UPDATES, this);
                location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            }

            if (location != null) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                set_latitude_txtbox(latitude);
                set_longtitude_txtbox(longitude);
                format_gps_coordinate(latitude, longitude);

                //37°24'34.3"N 122°06'42.9"W  == FORMAT_SECONDS -122:6:42.92892
                //System.out.println(latitude + " " + longitude);
                //System.out.println("FORMAT_MINUTES " + location.convert(longitude, Location.FORMAT_SECONDS));
            }
            //System.out.println("setup_location() Success");

        } catch (SecurityException se) {
            System.out.println("setup_location() SecurityException " + se.getMessage());
        } catch (Exception e) {
            System.out.println("setup_location() Exception " + e.getMessage());
        }
        return;
    }

    public void onLocationChanged(Location location) {
        //Code here, location.getAccuracy(), location.getLongitude() etc...
        Log.d(TAG, "onLocationChanged() ");

        get_update_location(location);
    }

    public void onStatusChanged(String provider, int status, Bundle extras) {
        System.out.println("onStatusChanged " + provider + "status " + status);
    }

    public void onProviderEnabled(String provider) {
        System.out.println("onProviderEnabled " + provider);
    }

    public void onProviderDisabled(String provider) {
        System.out.println("onProviderDisabled " + provider);

        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        startActivity(intent);
        Toast.makeText(getBaseContext(), "Gps is turned off!! ",
                Toast.LENGTH_SHORT).show();
    }

    public void get_update_location (Location location) {
        try {
            double curr_lat = location.getLatitude();
            double curr_lon = location.getLongitude();

            set_latitude_txtbox(curr_lat);
            set_longtitude_txtbox(curr_lon);

            String gps_info = "";

            gps_info = location.getElapsedRealtimeNanos()
                    + ":" + format_gps_coordinate(curr_lat, curr_lon)
                    + ":" + location.getSpeed()
                    + ":" + location.getAccuracy()
                    + ":"  + location.getAltitude();

            Log.d("Debug ", gps_info);

            debug.write(gps_info);

            WifiInfo wifiinfo = wm.getConnectionInfo();
            int ipnum = wifiinfo.getIpAddress();

            String ip_str = String.format("%d.%d.%d.%d", (ipnum & 0xff), (ipnum >> 8 & 0xff),
                    (ipnum >> 16 & 0xff), (ipnum >> 24 & 0xff));
            curr_ipaddr.setText(ip_str);

            //System.out.println(location.toString());
            String gps_loc = curr_lat + "," + curr_lon;
            gps_update_client.write_to_socket(gps_loc);

        } catch (SecurityException se) {
            System.out.println("get_current_location() SecurityException " + se.getMessage());
        } catch (Exception e) {
            System.out.println("get_current_location() Exception " + e.getMessage());
        }
        return;
    }


    private void set_latitude_txtbox(double latitude) {
        try {
            int degree_lat = (int) latitude;
            double md_lat = Math.abs(latitude - degree_lat) * 60;
            int m_lat = (int) md_lat;
            double sd_lat = ((md_lat - m_lat) * 60);
            char lat_hemispr = 'N';
            if (degree_lat < 0) {
                lat_hemispr = 'S';
            }
            String gps_str = String.format("%d° %d` %2.1f\" %c", Math.abs(degree_lat), m_lat, sd_lat, lat_hemispr);
            //System.out.println("Lati Local Function :" + gps_str);

            latit_txt.setText(gps_str);
        } catch (Exception er) {

        }
    }

    private void set_longtitude_txtbox(double longtiude) {
        try {
            int degree_longt = (int) longtiude;
            double md_longt = Math.abs(longtiude - degree_longt) * 60;
            int m_longt = (int) md_longt;
            double sd_longt = ((md_longt - m_longt) * 60);

            char logt_hemispr = 'E';
            if (degree_longt < 0) {
                logt_hemispr = 'W';
            }

            String gps_str = String.format("%d° %d` %2.1f\" %c", Math.abs(degree_longt), m_longt, sd_longt, logt_hemispr);
            //System.out.println("Longti Local Function :" + gps_str);

            longt_txt.setText(gps_str);
        } catch (Exception er) {

        }
    }
}
