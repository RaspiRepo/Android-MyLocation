
package raspirepo.mygpslocation;

public class gps_constant {

    public final static short HEADER_LENGTH           = 120; //bytes fixed heeader

    public final static short MINI_TIME_BW_UPDATES_SECS            = 5;
    public final static short MIN_DISTANCE_MTRS_CHANGE_FOR_UPDATES = 5;

};