/*----------------------------------------------------------------------------
    debug_log.java : debug log writting 

    Written by     : RaspiRepo
    Date           : Aug 30, 2016
------------------------------------------------------------------------------*/



package raspirepo.mygpslocation;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
 

import java.io.*;
import java.util.*;




public class debug_log
/*----------------------------------------------------------------------------
    debug_log      : Class allow to create write debug information

    Written by     : RaspiRepo
    Date           : Aug 30, 2016
------------------------------------------------------------------------------*/
{
    
    private PrintWriter writer = null;

    private DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private Date date = new Date(System.currentTimeMillis());
    private Context myapp_context = null;

    public debug_log (Context context) {
         myapp_context = context;
    }

    /* Checks if external storage is available for read and write */
    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            Log.d("Debug", "isExternalStorageWritable Yes");
            return true;
        }
        Log.d("Debug", "isExternalStorageWritable  NO");
        return false;
    }


    public void open (String logfile_name)
    /*------------------------------------------------------------------------
        open           : open debug log file
        
        Written by     : RaspiRepo
        Date           : Aug 30, 2016
    ------------------------------------------------------------------------*/
    {
        try {
            if (isExternalStorageWritable() == true) {
                File root = android.os.Environment.getExternalStorageDirectory();

                File dir = new File (root.getAbsolutePath() + "/gps_log");
                dir.mkdirs();
                File file = new File(dir, logfile_name);
                writer = new PrintWriter (new FileOutputStream(file));
            }
        } catch (IOException e) {
        }
    }


    public void open_debug_log ()
    /*------------------------------------------------------------------------
        open           : open debug log file
        
        Written by     : RaspiRepo
        Date           : Aug 30, 2016
    ------------------------------------------------------------------------*/
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String logfile_name = dateFormat.format(new Date()) + "_logs.txt";
        open(logfile_name);

        dateFormat = null;
    }



    public void write (String error_msg)
    /*------------------------------------------------------------------------
        writ           : write to debug log file
        
        Written by     : RaspiRepo
        Date           : Aug 30, 2016
    ------------------------------------------------------------------------*/
    {
        try {
            writer.print("[" + dateFormat.format(new Date()) + "] ");
            writer.println(error_msg);
            writer.flush();
        } catch (Exception e) {
        }
    }



    public void close ()
    /*------------------------------------------------------------------------
        close          : close debug log file
        
        Written by     : RaspiRepo
        Date           : Aug 30, 2016
    ------------------------------------------------------------------------*/
    {
        try {
            writer.close();
        } catch (Exception e) {
        }
    }
}